import React, { useState } from 'react';

function AddRecipe(props) {
  const [name, setName] = useState('');
  const [ingredients, setIngre] = useState('');
  const [instructions, setInstruct] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();

    props.onAddRecipe(name, ingredients,instructions);
    setName('');
    setIngre('');
    setInstruct('')
  };

  return (
    <div>
      <h2>Add Recipe</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="Recipe Name" value={name} onChange={(event) => setName(event.target.value)} />
        <input type="text" placeholder="Ingredients" value={ingredients} onChange={(event) => setIngre(event.target.value)} />
        <input type="text" placeholder="Instructions" value={instructions} onChange={(event) => setInstruct(event.target.value)} />
        <button type="submit">Add</button>
      </form>
    </div>
  );
}

export default AddRecipe;
