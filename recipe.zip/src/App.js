import React, { useState } from 'react';
import RecipeList from './RecipeList';
import AddRecipe from './AddRecipe';

function App() {
  const [recipes, setRecipes] = useState([
    { id: 1, name: 'Recipe 1', ingredients: 'x,y,z', instructions:'xyz' },
    
  ]);

  const handleAddRecipe = (name, ingredients, instructions) => {
    const newRecipe = {
      id: Date.now(),
      name: name,
      ingredients : ingredients,
      instructions: instructions
    };
    // console.log(newRecipe);
    setRecipes([...recipes, newRecipe]);
  };

  const handleDeleteRecipe = (id) => {
    const newRecipes = recipes.filter(recipe => recipe.id !== id);
    setRecipes(newRecipes);
  };

  return (
    <div>
      <h1>Recipe App</h1>
      <AddRecipe onAddRecipe={handleAddRecipe} />
      <RecipeList recipes={recipes} onDeleteRecipe={handleDeleteRecipe} />
    </div>
  );
}

export default App;
