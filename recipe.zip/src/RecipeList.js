import React from 'react';

function RecipeList(props) {
  const recipes = props.recipes;
//   console.log(recipes)
  const onDeleteRecipe = props.onDeleteRecipe;

  return (
    <div>
      <h2>Recipes</h2>
      <ul>
        {recipes.map(recipe => (
          <li key={recipe.id}>
            Title : {recipe.name}; 
            Ingredients : {recipe.ingredients};
            Instructions : {recipe.instructions}

            <button style={{ marginLeft : "20px" }} onClick={() => onDeleteRecipe(recipe.id)}>Delete</button>
          </li>
        ))}
      </ul>
      

      
    </div>
  );
}

export default RecipeList;
