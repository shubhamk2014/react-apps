import React, { useState } from 'react';
import axios from 'axios';

export default function Login() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = (event) => {
        event.preventDefault();
        axios.post('/api/login/', { username, password })
          .then((response) => {
            console.log(response.data);
       
          })
          .catch((error) => {
            console.error(error);
            // TODO: Display an error message to the user
          });
      };
    return (
        <>
            <h1 className=''>Log in</h1>
            <div>Sign in to continue</div>
            <div >
                <form onSubmit={handleSubmit}>
                    <label htmlFor="email">EMAIL</label>
                    <input type="email" value={username} onChange={(event) => setUsername(event.target.value)} />
                    <label htmlFor="pass">PASSWORD</label>
                    <input type="password" value={password} onChange={(event) => setPassword(event.target.value)} />
                    <button type="submit">Login</button>
                </form>
            </div>
        </>
    )
}
