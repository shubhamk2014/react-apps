import React, { useState } from 'react';

const UrlShortener = () => {
  const [url, setUrl] = useState('');
  const [shortUrl, setShortUrl] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    // Generate a short code for the long URL
    const shortCode = Math.random().toString(36).substring(2, 8);
    // Append the short code to a base URL to create the short URL
    const shortUrl = `https://bitly.com/${shortCode}`;
    setShortUrl(shortUrl);
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={url}
          onChange={(event) => setUrl(event.target.value)}
        />
        <button type="submit">Shorten URL</button>
      </form>
      {shortUrl && <p>Short URL: {shortUrl}</p>}
    </div>
  );
};

export default UrlShortener;

// import React, { useState } from 'react';
// import axios from 'axios';

// const UrlShortener = () => {
//   const [url, setUrl] = useState('');
//   const [shortUrl, setShortUrl] = useState('');

//   const handleSubmit = async (event) => {
//     event.preventDefault();
//     try {
//       const response = await axios.post(
//         'https://api-ssl.bitly.com/v4/shorten',
//         {
//           long_url: url,
//         },
//         {
//           headers: {
//             Authorization: 'Bearer d6978acaafd3303b3d9a9e4af801157021a7c564',
//             'Content-Type': 'application/json',
//           },
//         }
//       );
//       setShortUrl(response.data.link);
//     } catch (error) {
//       console.error(error);
//     }
//   };

//   return (
//     <div>
//       <form onSubmit={handleSubmit}>
//         <input
//           type="text"
//           value={url}
//           onChange={(event) => setUrl(event.target.value)}
//         />
//         <button type="submit">Shorten URL</button>
//       </form>
//       {shortUrl && <p>Short URL: {shortUrl}</p>}
//     </div>
//   );
// };

// export default UrlShortener;
