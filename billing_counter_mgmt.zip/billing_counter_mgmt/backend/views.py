from django.shortcuts import render
from rest_framework import viewsets
from backend.models import *
from backend.serializer import *

from django.contrib.auth import authenticate, login
from django.http import JsonResponse
# Create your views here.

class CustomerViewset(viewsets.ModelViewSet):
    queryset = Customers.objects.all()
    serializer_class = CustomerSerializer



def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return JsonResponse({'message': 'Logged in successfully'})
        else:
            return JsonResponse({'error': 'Invalid login credentials'}, status=400)
    else:
        return JsonResponse({'error': 'Invalid request method'}, status=400)
