from django.db import models

# Create your models here.

class Customers(models.Model):
    name = models.CharField(max_length=50)
    email = models.EmailField(null=False)
    mobile= models.CharField(max_length=15, unique=True)
    dob = models.DateField()
    created = models.DateTimeField(auto_now_add=True)