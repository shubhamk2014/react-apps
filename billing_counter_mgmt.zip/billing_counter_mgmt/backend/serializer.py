from rest_framework import serializers
from backend.models import *

class CustomerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Customers 
        fields = ['id', 'name', 'email','mobile','dob','created']