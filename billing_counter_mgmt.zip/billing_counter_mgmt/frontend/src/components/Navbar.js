import {TbLogout} from 'react-icons/tb'

export default function Navbar() {
  return (
    <>
    <div style={{display : 'flex', justifyContent : 'space-between',border: '2px solid black',marginTop: '2px', background:'#E8E8E8'}}>

        <h4 style={{paddingLeft: '20px'}}>Welcome Admin</h4>
        <h4>{new Date().toLocaleDateString()}<TbLogout style={{margin: '-2px 25px'}}/></h4>
        
    </div>
    
    </>
  )
}
